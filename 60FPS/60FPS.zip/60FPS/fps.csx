﻿#load "../../Stubs/RTDX.csx"

using System;
using System.Collections.Generic;
using System.Linq;
using SkyEditor.RomEditor.Domain.Rtdx.Structures;
using SkyEditor.RomEditor.Domain.Rtdx.Constants;
using SkyEditor.RomEditor.Infrastructure.Automation.Modpacks;

Rom.WriteFile("exefs/60fps.pchtxt", Mod.ReadResourceArray("Resources/60fps.pchtxt"));
